# Changes Made

## Updated
* For Items Find all, without vendor
* When adding items, do not check if category lies in the vendor
* When Searching for category, do not match the vendor
* GetItemByVendorId
 * Removed the vendor identification for Items

## Addition
* API for adding the banner


## Changes
* Check auth from user, customer order => Changed
* user controller -> notify api => Testing
* update changes in the customer order api => updated
* app.js for server keys


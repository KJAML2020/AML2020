const mongoose = require("mongoose");
const Coupon = require("./../models/MasterDataModels/Coupon");
const Role = require("../models/MasterDataModels/Role");

module.exports.AllCoupons = (req, res) => {
    console.log("adad");
    // res.send("Customer route is working.");
    Coupon.find()
        .then((coupon) => {
            console.log(coupon);
            res.writeHead(200, {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*",
            });
            res.write(
                JSON.stringify({
                    status: "success",
                    result: coupon,
                })
            );
            res.end();
        })
        .catch((error) => {
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};
module.exports.AddCoupon = async (req, res) => {
    const coupon_code = req.body.coupon_code;
    const percent = req.body.percent;
    const coupon = new Coupon({
        coupon_code: coupon_code,
        percent: percent,
    });
    coupon
        .save()
        .then((data) => {
            console.log(data);
            res.writeHead(200, {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*",
            });
            res.write(
                JSON.stringify({
                    status: "success",
                    result: {
                        coupon_code: data.coupon_code,
                        percent: data.percent,
                    },
                })
            );
            res.end();
        })
        .catch((error) => {
            console.log("dsds");
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};
module.exports.UserCouponValidation = async (req, res) => {
    const { vendorId, coupon } = req.body;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: req.userData.role });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "CUSTOMER") {
        return res.json({
            success: false,
            result: { error: "You are not Authorized to do this task" },
        });
    }
    let CheckCoupon;
    try {
        CheckCoupon = await Coupon.findOne({
            coupon_code: { $in: [coupon] },
        });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!CheckCoupon) {
        return res.json({
            success: false,
            result: {
                error: "Invalid Coupon or Coupon has Expired",
            },
        });
    }
    return res.json({
        success: true,
        result: {
            result: CheckCoupon.percent,
        },
    });
};
module.exports.DeleteCoupon = async (req, res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    // if (roleOfUser.name !== "VENDOR") {
    //     return res.json({
    //         success: false,
    //         result: { error: "You are not allowed to do this task" },
    //     });
    // }
    const removecoupon = await Coupon.remove({ _id: req.params.couponId });
    res.json({
        success: true,
        result: { result: "Coupon Deleted Successfully" },
    });
};

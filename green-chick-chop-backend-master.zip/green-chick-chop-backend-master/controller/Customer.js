const mongoose = require("mongoose");
const Customer = require("./../models/UserModels/Customer");
const User = require("./../models/MasterDataModels/User");
const CustomerAddress = require("./../models/MasterDataModels/CustomerAddress");


module.exports.GetAllCustomers = (req, res) => {
    // res.send("Customer route is working.");
    Customer.find().populate({path : 'user',select : 'name'})
        .then((customer) => {
            res.writeHead(200, {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*",
            });
            res.write(
                JSON.stringify({
                    status: "success",
                    result: customer,
                })
            );
            res.end();
        })
        .catch((error) => {
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};

module.exports.AddCustomer = async (req, res) => {
    const user = req.body.user;
    const image_url = req.body.image_url;
    const current_location = req.body.current_location;

    const customer = new Customer({
        user: user,
        image_url: image_url,
        current_location: current_location,
    });

    customer.save().then((data) => {
        console.log(data);
        res.writeHead(200, {
            "Content-Type": "text/json",
            "Access-Control-Allow-Origin": "*",
        });
        res.write(
            JSON.stringify({
                status: "success",
                result: {
                    "user": user,
                    "imageUrl": image_url,
                    "current_location": current_location,
                },
            })
        );
        res.end();
    })
    .catch((error) => {
        res.write(
            JSON.stringify({
                status: "false",
                error: console.error(error),
            })
        );
    });
    
};

module.exports.GetCustomerById = async (req, res) => {
    try {
        let existingCustomer = await Customer.findOne({ _id: req.params.userId }).populate({path : 'user',select : ['name','mobile','email']})
        return res.json({
            success: true,
            result: existingCustomer,
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
};

module.exports.GetCustomerAddressById = async (req, res) => {
    try {
        let existingCustomer = await CustomerAddress.findOne({ _id: req.params.AddressId });
        return res.json({
            success: true,
            result: existingCustomer,
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
};

module.exports.DeleteCustomer = async (req, res) => {
    const removecustomer = await Customer.remove({ _id: req.params.userId });
    res.json(removecustomer);
};

module.exports.UpdateCustomer = async (req, res) => {
    const updatedcustomer = await Customer.updateOne(
        { _id: req.params.userId },
        { $set: { current_location: req.body.current_location } }
    );
    res.json(updatedcustomer);
};

module.exports.AddAddress = async (req, res) => {
    const userId = req.userData.userId;
    let existingCustomer;
    try {
        existingCustomer = await Customer.findOne({ user: userId });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
    if (!existingCustomer) {
        return res.json({
            success: false,
            result: {
                error: "Customer not Exists",
            },
        });
    }
    const { address, city, state, pin_code, landmark } = req.body;

    const createdAddress = new CustomerAddress({
        customer: existingCustomer._id,
        address,
        city,
        state,
        pin_code,
        landmark,
    });

    try {
        await createdAddress.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Something Went Wrong" },
        });
    }

    return res.json({
        success: true,
        result: { result: "Address Updated Successfully" },
    });
};

module.exports.GetAddress = async (req, res) => {
    console.log("Display here")
    const userId = req.userData.userId;
    let existingCustomer;
    try {
        existingCustomer = await Customer.findOne({ user: userId });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
    if (!existingCustomer) {
        return res.json({
            success: false,
            result: {
                error: "Customer not Exists",
            },
        });
    }
    let existingAddresses;
    try {
        existingAddresses = await CustomerAddress.find({
            customer: existingCustomer._id,
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Not Found any Address" },
        });
    }
    res.json({
        success: true,
        result: {
            result: existingAddresses,
        },
    });
};

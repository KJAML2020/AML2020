const Order = require("./../models/VendorModels/orders");
const Role = require("./../models/MasterDataModels/Role");
const ItemCategory = require("./../models/MasterDataModels/ItemCategory");
const CustomerAddress = require("./../models/MasterDataModels/CustomerAddress");
const Customer = require("../models/UserModels/Customer");
const DelieveryStatus = require("../models/MasterDataModels/DeliveryStatus");
const Payment = require("../models/MasterDataModels/Payment");
const Vendor = require("./../models/UserModels/vendors");
const Common = require("./../validations/common");
const moment = require('moment')
const msg91 = require("msg91")("255962AGzSDmitPVg5c36ea9e", "SMSIND", "4" );
const FCM = require('fcm-node');
const serverKey = 'AAAAtXROo6Y:APA91bE146IIaN_ags3lSAIlqIyCWIgke_58u5PpsDpJ3AVHKCKVdPmGt4iojVBrYemicAMND8oV00IJFYLQXxT4MVOtK6VKWlzQo0SdwjHg1ZOsvPNoaTGad8Nz4dHwptd7tRxoBvGf';

module.exports.AllCustomerOrders = async (req, res) => {
    const roleId = req.userData.role;
    const device = req.query.device;
    console.log(device)
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
        console.log(roleOfUser)
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        var twoDayBack = new Date();
        twoDayBack.setDate(twoDayBack.getDate() - 2);
        if(roleOfUser.name == "VENDOR"){
            result = await Order.find({ vendor_id: req.userData.userId }).populate('payment').populate('delivery_status','status').sort({created_on: -1})
        }else if(roleOfUser.name == "ADMIN"){
            if(device === 'web'){
                result = await Order.find({}).populate('payment').populate('delivery_status','status')
            }else{
                result = await Order.find({
                    created_on: {
                      $gte: new Date(twoDayBack)
                    }
                  }).populate('payment').populate('delivery_status','status').sort({created_on: -1})
            }
        }
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

module.exports.GetVendorAnalysis = async (req, res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    let analysis = {}
    try {
        let lastWeekStartDate = new Date();
        lastWeekStartDate = lastWeekStartDate.setDate(lastWeekStartDate.getDate() - 7)
        if(roleOfUser.name === "VENDOR"){
            result = await Order.find({ vendor_id: req.userData.userId }).populate('payment').populate('delivery_status','status')
        }else{
            result = await Order.find().populate('payment').populate('delivery_status','status')
        }
        result.sort(function(a,b){
            return new Date(a.order_date) - new Date(b.order_date);
        });
        let totalAmount = 0;
        let lastWeekCollection = 0;
        result.forEach((orderEntry)=>{
            if(orderEntry != null && orderEntry.payment != undefined && orderEntry.payment.amount != undefined){
                if( new Date(orderEntry.order_date).getTime() >= new Date(lastWeekStartDate).getTime()){
                    lastWeekCollection += orderEntry.payment.amount
                }
                totalAmount += orderEntry.payment.amount
            }
        })
        let minDate = result[0].order_date;
        let maxDate = result[ result.length - 1 ].order_date;
        let differenceInTime = new Date(maxDate).getTime() - new Date(minDate).getTime(); 
        let differenceInDays = differenceInTime / (1000 * 3600 * 24); 

        analysis["total_revenue"] = totalAmount
        analysis["total_orders_served"] = result.length
        analysis["last_week_revenue"] = lastWeekCollection
        analysis["average_revenue_per_day"] = (totalAmount/differenceInDays)
        analysis["average_orders_per_day"] = (result.length/differenceInDays)
        if(result.length != 0){
            analysis["average_value_per_order"] = parseFloat((totalAmount/ (result.length)).toFixed(2)) 
        }else{
            analysis["average_value_per_order"] = 0
        }
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: analysis } });
};

module.exports.UpdateDeliveryStatus = async (req, res) => {
    try {
        const orderId = req.body.orderId;
        const deliveryStatus = req.body.statusId;
        const deliveryStatusName = req.body.statusName;
        const deliveryData = new Date();
        const orderDetail = await Order.findOneAndUpdate({ _id: orderId }, {delivery_status: deliveryStatus, delivery_date: deliveryData});
        try{
            console.log(deliveryStatusName)
            if(  deliveryStatusName  == 'PURCHASED'){
                let customer = await Customer.findOne({ _id: orderDetail.customer_id }).populate({path : 'user',select : ['name','mobile','email']})
                msg91.send( "91"+customer.user.mobile, "Dear " + customer.user.name + ", your order at Green Chick Chop has been confirmed by the outlet.", function(err, response){
                    console.log(err);
                    console.log(response);
                });
                console.log("Delivered")
            }else{
                let customer = await Customer.findOne({ _id: orderDetail.customer_id }).populate({path : 'user',select : ['name','mobile','email']})
                msg91.send( "91"+customer.user.mobile, "Dear " + customer.user.name + ", your order is "+ deliveryStatusName, function(err, response){
                    console.log(err);
                    console.log(response);
                });
                console.log("Delivered")
            }
            
        }catch(e){

        }
        return res.json({ success: true });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

module.exports.AddCustomerOrder = async (req, res) => {
    const userId = req.userData.userId;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: req.userData.role });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "CUSTOMER") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    const {
        itemPayload,
        selectedAddress,
        delieveryDate,
        delieveryTime,
        modeOfPayment,
        totalCost,
        payment_ref_id,
    } = req.body;

    if (itemPayload.length === 0) {
        return res.json({
            success: false,
            result: { error: "Invalid Request, Please ,add Item" },
        });
    }

    let check_customer_address;
    try {
        check_customer_address = await CustomerAddress.findOne({
            address: { $in: [selectedAddress.address] },
            city: { $in: [selectedAddress.city] },
            state: { $in: [selectedAddress.state] },
            pin_code: { $in: [selectedAddress.pincode] },
        });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!check_customer_address) {
        return res.json({
            success: false,
            result: { error: "Address Is Invalid, please Add your Address" },
        });
    }

    let status_of_delievery;
    try {
        status_of_delievery = await DelieveryStatus.findOne({
            status: "PENDING",
        });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!status_of_delievery) {
        return res.json({
            success: false,
            result: { error: "Something went Wrong" },
        });
    }

    let customer_ref;
    try {
        customer_ref = await Customer.findOne({ user: userId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!customer_ref) {
        return res.json({
            success: false,
            result: { error: "User Not Authorized" },
        });
    }

    const payment_reference_id = payment_ref_id || null;

    const createdPayment = new Payment({
        instrument: modeOfPayment,
        amount: totalCost,
        status: "PENDING",
        payment_ref_id: payment_reference_id,
    });
    try {
        await createdPayment.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are mismatched , check body", err },
        });
    }

    const createdOrder = new Order({
        customer_id: customer_ref._id,
        order_uid: Common.uuid(),
        vendor_id: req.params.vendorId,
        order_date: delieveryDate,
        order_time: delieveryTime,
        delivery_status: status_of_delievery._id,
        orderItem: itemPayload,
        delievery_address: check_customer_address._id,
        payment: createdPayment.id,
    });

    //Get the mobile number of the customer and vendor
    try{
        let customerDetail = await Customer.findOne({ _id: customer_ref._id }).populate({path : 'user',select : ['name','mobile','email']})
        let vendorDetail = await Vendor.find({'user_id':req.params.vendorId}).populate({path : 'user_id',select : ['name','email','mobile','web_fcm']})
        console.log("Address :",selectedAddress)
        let deliveryAddress = selectedAddress.address + " " + selectedAddress.city + " " + selectedAddress.state + " " + selectedAddress.pincode;

        let vendorMsg = "Order Details:\n";
        if(itemPayload != null && itemPayload.length > 0){
            itemPayload.forEach((item, index)=>{
                vendorMsg += item.itemName +" x " + item.quantity + "\n"
            })
        }
        //Forming the customer details
        vendorMsg += "\nCustomer Details:\n";
        vendorMsg += "Name: " + customerDetail.user.name + "\n";
        vendorMsg += "Mobile: " + customerDetail.user.mobile;
        vendorMsg += "Address: \n" + deliveryAddress;

        msg91.send( "91"+vendorDetail[0].user_id.mobile, vendorMsg, function(err, response){
            console.log(err);
            console.log(response);
        });

        //Send notification
        if(vendorDetail[0].user_id.web_fcm !== null && vendorDetail[0].user_id.web_fcm !== undefined){
            var serverKey = 'AAAAtXROo6Y:APA91bE146IIaN_ags3lSAIlqIyCWIgke_58u5PpsDpJ3AVHKCKVdPmGt4iojVBrYemicAMND8oV00IJFYLQXxT4MVOtK6VKWlzQo0SdwjHg1ZOsvPNoaTGad8Nz4dHwptd7tRxoBvGf';
            var fcm = new FCM(serverKey);
    
            var message = { 
                to: vendorDetail[0].user_id.web_fcm,
                collapse_key: 'collapse_key',
                
                notification: {
                    title: 'GreenChickChop: New Order', 
                    body: 'New order placed. Please click to check.' 
                },
                
                data: {  
                    my_key: 'my value',
                    my_another_key: 'my another value'
                }
            };
    
            fcm.send(message, function(err, response){
                if (err) {
                    console.log("Something has gone wrong!");
                } else {
                    console.log("Successfully sent with response: ", response);
                }
            });
        }
    }catch(e){

    }

    try {
        await createdOrder.save();
    } catch (err) {
        try {
            await Payment.remove({ _id: createdPayment.id });
        } catch (error) {
            return res.json({
                success: false,
                result: { error: error },
            });
        }
        return res.json({
            success: false,
            result: { error: "Fields are mismatched , check body", err },
        });
    }
    res.json({
        success: true,
        result: { result: "Order Added Successfully" },
    });
};

module.exports.UpdateCustomerOrder = async (req, res) => {
    const roleId = req.userData.roleId;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "CUSTOMER") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        result = await Order.findOne({ _id: req.params.orderId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!result) {
        return res.json({
            success: false,
            result: { error: "Order is not present in Database" },
        });
    }

    try {
        await Item.findOneAndUpdate({ _id: result._id }, req.body.orderDetail);
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "order Updated SuccessFully" },
    });
};

module.exports.UpdateOrderByVendor = async (req, res) => {
    const roleId = req.userData.roleId;
    const delieveryStatus = req.body.delieveryStatus.toUpperCase();
    const order_change_date = req.body.order_date;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        result = await Order.findOne({ order_uid: req.params.orderUid });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!result) {
        return res.json({
            success: false,
            result: { error: "Order is not present in Database" },
        });
    }
    let delievery_status_name;
    if (delieveryStatus) {
        try {
            delievery_status_name = await DelieveryStatus.findOne({
                status: delieveryStatus,
            });
        } catch (err) {
            return res.json({ success: false, result: { error: err } });
        }
        if (!delievery_status_name) {
            return res.json({
                success: false,
                result: {
                    error: "Delievery status is not present in Database",
                },
            });
        }
    }
    let payload;
    if (delieveryStatus && order_change_date) {
        payload = {
            order_date: order_change_date,
            delivery_status: delievery_status_name._id,
        };
    } else if (delieveryStatus && !order_change_date) {
        payload = { delivery_status: delievery_status_name._id };
    } else if (!delieveryStatus && order_change_date) {
        payload = { order_date: order_change_date };
    } else {
        return res.json({
            success: false,
            result: { error: "Required Field Missing" },
        });
    }

    try {
        await Order.findOneAndUpdate({ _id: result._id }, payload);
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "order Updated SuccessFully" },
    });
};

module.exports.DeleteCustomerOrder = async (req, res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "CUSTOMER") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let order;
    try {
        order = await Order.findOne({ _id: req.params.orderUid });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!order) {
        return res.json({
            success: false,
            result: { error: "Item is not Present" },
        });
    }

    try {
        await Order.remove({ _id: order._id });
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    return res.json({
        success: true,
        result: { result: "Order Deleted Successfully" },
    });
};

module.exports.GetOrdersDetail = async (req, res) => {
    const userId = req.userData.userId;
    let customer_ref;
    try {
        customer_ref = await Customer.findOne({ user: userId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!customer_ref) {
        return res.json({
            success: false,
            result: { error: "User Not Authorized" },
        });
    }
    let result;
    try {
        result = await Order.find({ customer_id: customer_ref._id })
            .populate("payment")
            .populate("delivery_status");
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

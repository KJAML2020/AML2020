const mongoose = require("mongoose");
const CustomerQueries = require("./../models/UserModels/queries");
const User = require("./../models/MasterDataModels/User");

module.exports.AllCustomerQueries =  (req, res) =>{
    

    // res.send("Customer route is working.");
    CustomerQueries.find()
       .then((customerqueries) => {
            console.log("abc", customerqueries)
            res.writeHead(200, { 'Content-Type': 'text/json', 'Access-Control-Allow-Origin': '*' });
            res.write(JSON.stringify({
               status : "success",
               result : customerqueries,
                
            }));
            res.end();  
        })
        .catch(error =>{
            res.write(JSON.stringify({
                status : "false",
                error :  console.error(error),      
             }));

        })
    
    
}

module.exports.AddCustomerQueries = async (req ,res) =>{

    const user = req.body.user;
    const email = req.body.email;
    const password = req.body.password;
    const message = req.body.message;
    const queryType = req.body.queryType;
    

    const customerqueries = new CustomerQueries({
        
        user : user,
        email : email,
        password : password,
        message : message,
        queryType : queryType

    })

    customerqueries.save()
    .then((data) => {
        console.log(data)
        res.writeHead(200, {'Content-Type':'text/json','Access-Control-Allow-Origin':'*'})
        res.write(JSON.stringify({
            status : "success",
            result : { 
                        "user" : user,
                        "email" : email, 
                        "password" : password,
                        "message" : message,
                        "queryType": queryType

            }
        }));
        res.end();
    

})
} 



module.exports.DeleteCustomerQueries = async (req ,res) =>{

   const removecustomerqueries = await CustomerQueries.remove({_id : req.params.userId});
   res.json(removecustomerqueries);

}

module.exports.UpdateCustomerQueries = async (req,res) => {

    const updatedcustomerqueries = await CustomerQueries.updateOne({_id: req.params.userId},{ $set : { email : req.body.email, password : req.body.password}});
    res.json(updatedcustomerqueries);
};
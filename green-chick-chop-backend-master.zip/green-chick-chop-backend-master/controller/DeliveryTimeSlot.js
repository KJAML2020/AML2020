const mongoose = require("mongoose");
const DeliveryTimeSlot = require("../models/MasterDataModels/DeliveryTimeSlots");
const Role = require('../models/MasterDataModels/Role');

module.exports.AllTimeSlots =  (req, res) =>{
    

    // res.send("Customer route is working.");
    DeliveryTimeSlot.find()
       .then((deliverytimeslot) => {
            console.log("abc", deliverytimeslot)
            res.writeHead(200, { 'Content-Type': 'text/json', 'Access-Control-Allow-Origin': '*' });
            res.write(JSON.stringify({
               status : "success",
               result : deliverytimeslot,
                
            }));
            res.end();  
        })
        .catch(error =>{
            res.write(JSON.stringify({
                status : "false",
                error :  console.error(error),      
             }));

        })
    
    
}

module.exports.AddTimeSlot = async (req ,res) =>{
    const roleId = req.userData.role;
    const delivery_time_slot = req.body.delivery_time_slot;
    const delivery_date = req.body.delivery_date;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    console.log(req.userData.userId)

    const deliverytimeslot = new DeliveryTimeSlot({
        vendor_id: req.userData.userId,
        delivery_time_slot : delivery_time_slot,
        delivery_date : delivery_date,
    })

    deliverytimeslot.save()
    .then((data) => {
        console.log(data)
        res.writeHead(200, {'Content-Type':'text/json','Access-Control-Allow-Origin':'*'})
        res.write(JSON.stringify({
            status : "success",
            result : {  "vendor_id": data.vendor_id,
                        "delivery_time_slot" : delivery_time_slot,
                        "delivery_date" : delivery_date,
                      
            }
        }));
        res.end();
    })
    .catch((error) => {
        console.log("dsds")
        res.write(
            JSON.stringify({
                status: "false",
                error: console.error(error),
            })
        );
    });
} 



module.exports.DeleteTimeSlot= async (req ,res) =>{
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

   const removetimeslot = await DeliveryTimeSlot.remove({_id : req.params.userId});
   res.json({
    success: true,
    result: { result: "Time Slot Deleted Successfully" },
});

}

module.exports.UpdateTimeSlot = async (req,res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    const updatetimeslot = await DeliveryTimeSlot.updateOne({_id: req.params.userId},{ $set : { delivery_time_slot : req.body.delivery_time_slot,delivery_date : req.body.delivery_date}});
    res.json({
        success: true,
        result: { result: "Time Slot Updated Successfully" },
    });;
};
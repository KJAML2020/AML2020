const mongoose = require("mongoose");
const ItemCategory = require("./../models/MasterDataModels/ItemCategory");
const Role = require("../models/MasterDataModels/Role");

module.exports.AllItemCategory = async (req, res) => {
    const roleId = req.userData.role;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        // result = await ItemCategory.find({ vendor_id: req.userData.userId });
        result = await ItemCategory.find();
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

module.exports.AddItemCategory = async (req, res) => {
    const roleId = req.userData.role;
    const { name, image, icon } = req.body;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    const createdCategory = new ItemCategory({
        vendor_id: req.userData.userId,
        name: name,
        image: image,
        icon: icon,
    });

    try {
        await createdCategory.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are Mismatched" },
        });
    }

    return res.json({
        success: true,
        result: { result: "Item Category Added Successfully" },
    });
};

module.exports.DeleteItemCategory = async (req, res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    try {
        await ItemCategory.remove({ _id: req.params.userId });
    } catch (err) {
        res.json({
            success: true,
            result: { result: "Something went wrong" },
        });
    }
    res.json({
        success: true,
        result: { result: "Item Category Deleted Successfully" },
    });
};

module.exports.UpdateItemCategory = async (req, res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    console.log("Update called")
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    await ItemCategory.updateOne(
        { _id: req.params.userId },
        { $set: { name: req.body.name , icon: req.body.icon , image: req.body.image } }
    );
    res.json({
        success: true,
        result: { result: "Item Category Updated Successfully" },
    });
};

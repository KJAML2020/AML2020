const Testimonial = require("./../models/UserModels/testimonials");

module.exports.AllTestimonials = async (req, res) => {
    let result;
    try {
        result = await Testimonial.find({});
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

module.exports.AddTestimonial = async (req, res) => {
    const roleId = req.userData.role;

    const { name, icon, description, image_url, rating } = req.body;

    const testimonial = new Testimonial({
        name,
        user_id: req.userData.userId,
        icon,
        description,
        image_url,
        rating,
    });

    let roleOfUser;
    // try {
    //     roleOfUser = await Role.findOne({ _id: roleId });
    // } catch (err) {
    //     return res.json({ success: false, result: { error: err } });
    // }
    // if (roleOfUser.name !== "ADMIN") {
    //     return res.json({
    //         success: false,
    //         result: { error: "You are not allowed to do this task" },
    //     });
    // }

    try {
        await testimonial.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are missing , check body" },
        });
    }
    res.json({
        success: true,
        result: { result: "Testimonial Added Successfully" },
    });
};

module.exports.DeleteTestimonial = async (req, res) => {
    const roleId = req.userData.role;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    try {
        await Testimonial.remove({
            _id: req.params.testimonialId,
        });
    } catch (error) {
        res.json({
            success: false,
            result: { result: "something went wrong" },
        });
    }
    res.json({
        success: true,
        result: { result: "Testimonial deleted Successfully" },
    });
};

module.exports.UpdateTestimonial = async (req, res) => {
    const roleId = req.userData.role;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    try {
        await Testimonial.updateOne(
            { user_id: req.params.testimonialId },
            { $set: { description: req.body.description } }
        );
    } catch (err) {
        return res.json({
            success: false,
            result: { error: err },
        });
    }
    res.json({
        success: true,
        result: { result: "Testimonial Updated Successfully" },
    });
};

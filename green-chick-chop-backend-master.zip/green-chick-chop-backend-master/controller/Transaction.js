const mongoose = require("mongoose");
const Transaction = require("./../models/UserModels/Transaction");
const Customer = require("./../models/UserModels/Customer");
const Vendor = require("./../models/UserModels/vendors");
const Order = require("./../models/VendorModels/orders")

module.exports.AllTransaction = (req, res) => {
    // res.send("Customer route is working.");
    Transaction.find()
        .then((transaction) => {
            res.writeHead(200, {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*",
            });
            res.write(
                JSON.stringify({
                    status: "success",
                    result: transaction,
                })
            );
            res.end();
        })
        .catch((error) => {
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};
module.exports.AddTransaction = async (req, res) => {
    const roleId = req.userData.role;
    const customer_id = req.body.customer_id;
    const vendor_id = req.body.vendor_id;
    const amount = req.body.amount;
    const order_id = req.body.order_id;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    const transaction = new Transaction({
        vendor_id: req.userData.userId,
        customer_id : req.userData.userId,
        amount : amount,
        order_id: req.orderData.order_id
    });

    transaction.save().then((data) => {
        console.log(data);
        res.writeHead(200, {
            "Content-Type": "text/json",
            "Access-Control-Allow-Origin": "*",
        });
        res.write(
            JSON.stringify({
                status: "success",
                result: {
                    "vendor_id": vendor_id,
                    "customer_id": customer_id,
                    "amount": amount,
                    "order_id": order_id,
                },
            })
        );
        res.end();
    })
    .catch((error) => {
        res.write(
            JSON.stringify({
                status: "false",
                error: console.error(error),
            })
        );
    });
    
};
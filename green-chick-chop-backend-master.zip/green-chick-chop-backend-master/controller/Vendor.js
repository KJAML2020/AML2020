const mongoose = require("mongoose");
const Vendor = require("./../models/UserModels/vendors");
const User = require("./../models/MasterDataModels/User");
const Order = require("./../models/VendorModels/orders");
const Role = require("./../models/MasterDataModels/Role");

module.exports.AllVendors = (req, res) => {
    Vendor.find().populate({path : 'user_id',select : ['name','email','mobile']})
        .then((vendor) => {
            res.writeHead(200, {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*",
            });
            res.write(
                JSON.stringify({
                    status: "success",
                    result: vendor,
                })
            );
            res.end();
        })

        .catch((error) => {
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};

module.exports.GetVendorById = async (req, res) => {
    const vendorId = req.params.vendorId;
    Vendor.find({'user_id':vendorId}).populate({path : 'user_id',select : ['name','email','mobile']})
        .then((vendor) => {
            if(vendor.length == 0){
                res.writeHead(200, {
                    "Content-Type": "text/json",
                    "Access-Control-Allow-Origin": "*",
                });
                res.write(
                    JSON.stringify({
                        status: "success",
                        result: [{
                            "address": "Green Chick Chop - India",
                            "user_id": {
                                "name": "Green Chick Chop Admin",
                                "email": "admin@gcc.in",
                                "mobile": 9971581111
                            }
                        }],
                    })
                );
                res.end();
            }else{
                res.writeHead(200, {
                    "Content-Type": "text/json",
                    "Access-Control-Allow-Origin": "*",
                });
                res.write(
                    JSON.stringify({
                        status: "success",
                        result: vendor,
                    })
                );
                res.end();
            }
            
        })

        .catch((error) => {
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};

module.exports.GetVendorByVendorId = (req, res) => {
    const vendorId = req.params.vendorId;
    Vendor.find({'_id':vendorId}).populate({path : 'user_id',select : ['name','email','mobile']})
        .then((vendor) => {
            res.writeHead(200, {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*",
            });
            res.write(
                JSON.stringify({
                    status: "success",
                    result: vendor,
                })
            );
            res.end();
        })

        .catch((error) => {
            res.write(
                JSON.stringify({
                    status: "false",
                    error: console.error(error),
                })
            );
        });
};

module.exports.AddVendor = async (req, res) => {
    const user_id = req.body.user;
    const location = JSON.parse(req.body.location);
    const delivery_date_range = req.body.delivery_date_range;
    const address = req.body.address;
    const delivery_time_slots = req.body.delivery_time_slots;
    const payment_gateway_id = req.body.payment_gateway_id;
    const image_url = req.body.image_url;
    console.log(user_id);
    const vendor = new Vendor({
        user_id: user_id,
        image_url: image_url,
        location : location,
        address : address,
        delivery_date_range : delivery_date_range,
        delivery_time_slots : delivery_time_slots,
        payment_gateway_id : payment_gateway_id,
    });
    vendor.save().then((data) => {
        console.log(data);
        res.writeHead(200, {
            "Content-Type": "text/json",
            "Access-Control-Allow-Origin": "*",
        });
        res.write(
            JSON.stringify({
                status: "success",
                result: {
                        "user_id": user_id,
                        "imageUrl": image_url,
                        "location": {latitude: parseFloat(location.latitude), longitude: parseFloat(location.longitude), },
                        "address" : address,
                        "delivery_date_range" : delivery_date_range,
                        "delivery_time_slots" : delivery_time_slots,
                        "payment_gateway_id" : payment_gateway_id,
                    
                },
            })
        );
        res.end();
    })
    .catch((error) => {
        res.write(
            JSON.stringify({
                status: "false",
                error: console.error(error),
            })
        );
    });
    
};

module.exports.DeleteVendor = async (req, res) => {
    //Delete the user also not just the venndor
    const removevendor = await Vendor.remove({ user_id: req.params.userId });
    const removeuser = await User.remove({ _id: req.params.userId });
    res.json({
        success: true,
        result: { result: "Vendor Deleted Successfully" },
    });

},

module.exports.UpdateVendor = async (req, res) => {
    const updatedvendor = await Vendor.updateOne(
        { _id: req.params.userId },
        { $set: { image_url: req.body.image_url, delivery_date_range : req.body.delivery_date_range,delivery_time_slots : req.body.delivery_time_slots } }
    );
    res.json({
        success: true,
        result: { result: "Vendor Updated Successfully" },
    });;
};




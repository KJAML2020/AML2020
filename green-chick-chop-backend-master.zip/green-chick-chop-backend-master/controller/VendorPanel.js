const mongoose = require("mongoose");
const Customer = require("./../models/UserModels/Customer");
const Vendor = require("./../models/UserModels/vendors");
const User = require("./../models/MasterDataModels/User");
const Order = require("./../models/VendorModels/orders");


module.exports.GetCustomerById = async (req, res) => {
    try {
        
        let existingCustomer = await Customer.findOne({ _id: req.params.userId }).populate({path : 'user',select : ['name','mobile','email']})
        return res.json({
            success: true,
            result: existingCustomer,
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
};

module.exports.GetCustomerAddressById = async (req, res) => {
    try {
        let existingCustomer = await CustomerAddress.findOne({ _id: req.params.AddressId });
        return res.json({
            success: true,
            result: existingCustomer,
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
};

module.exports.GetAnalysis = async (req, res) => {
    try {
        let vendor = await Vendor.count({});
        let customer = await Customer.count({});
        let order = await await Order.find().select({ "order_date": 1, "_id": 0,'payment':1}).populate('payment','amount')
        return res.json({
            success: true,
            result : {
                vendor: vendor,
                customer: customer,
                order:  order
            }
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
};

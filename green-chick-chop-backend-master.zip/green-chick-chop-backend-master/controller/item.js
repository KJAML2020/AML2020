const Item = require("../models/VendorModels/items");
const Role = require("./../models/MasterDataModels/Role");
const ItemCategory = require("./../models/MasterDataModels/ItemCategory");
const ItemTag = require("./../models/MasterDataModels/ItemTag");

module.exports.GetAllItems = async (req, res) => {
    const roleId = req.userData.role;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        // result = await Item.find({ vendor_id: req.userData.userId });
        result = await Item.find();
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

module.exports.GetItemById = async (req, res) => {
    const roleId = req.userData.role;
    const itemId = req.params.itemId;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    /* Temporary removed as per customer demand */
    // if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
    //     return res.json({
    //         success: false,
    //         result: { error: "You are not allowed to do this task" },
    //     });
    // }
    let result;
    try {
        result = await Item.find({ _id: itemId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({ success: true, result: { result: result } });
};

module.exports.AddItem = async (req, res) => {
    const roleId = req.userData.role;
    const {
        item_tag,
        item_category,
        max_qty_available,
        name,
        image_url,
        packaging_type,
        price,
        description,
        discount,
    } = req.body;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    if (
        !item_tag &&
        !item_category &&
        // !price &&
        !description &&
        !name &&
        !image_url &&
        // !packaging_type &&
        !max_qty_available &&
        !discount
    ) {
        return res.json({
            success: false,
            result: { error: "Required Field is missing" },
        });
    }
    let category_name;
    try {
        category_name = await ItemCategory.findOne({
            // vendor_id: { $in: [req.userData.userId] },
            name: item_category,
        });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!category_name) {
        return res.json({
            success: false,
            result: { error: "No Category for this Item" },
        });
    }

    //Get the array options
    console.log(req.body.multi_price)
    console.log(req.body.multi_package)
    let multi_price = req.body.multi_price;
    let multi_package =req.body.multi_package;

    const createdItem = new Item({
        vendor_id: req.userData.userId,
        item_category: category_name._id,
        item_tag: item_tag,
        price,
        multi_package: multi_package,
        multi_price: multi_price,
        description,
        name,
        image_url,
        packaging_type,
        max_qty_available,
        discount,
    });

    try {
        await createdItem.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are mismatched , check body" },
        });
    }
    let category_count = category_name.max_qty_available + 1;
    try {
        await ItemCategory.updateOne(
            { _id: category_name._id },
            { $set: { max_qty_available: category_count } }
        );
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    res.json({
        success: true,
        result: { result: "Item Added Successfully" },
    });
};

module.exports.UpdateItem = async (req, res) => {
    const roleId = req.userData.role;
    const itemId = req.params.itemId;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR" && roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        result = await Item.findOne({ _id: itemId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!result) {
        return res.json({
            success: false,
            result: { error: "Item is not present in Database" },
        });
    }

    let itemDetail = JSON.parse(req.body.itemDetail)

    let category_name;
    try {
        category_name = await ItemCategory.findOne({
            // vendor_id: { $in: [req.userData.userId] },
            name: itemDetail.item_category,
        });
        itemDetail.item_category = category_name._id;
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!category_name) {
        return res.json({
            success: false,
            result: { error: "No Category for this Item" },
        });
    }

    console.log("Item Detail: ", itemDetail)

    try {
        await Item.findOneAndUpdate({ _id: itemId }, itemDetail);
    } catch (error) {
        console.log("Error: ",error)
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "Item Updated SuccessFully" },
    });
};

module.exports.DeleteItem = async (req, res) => {
    const roleId = req.userData.role;
    const itemId = req.params.itemId;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let item;
    try {
        item = await Item.findOne({ _id: itemId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!item) {
        return res.json({
            success: false,
            result: { error: "Item is not Present" },
        });
    }

    let category_quantity;
    try {
        category_quantity = await ItemCategory.findOne({
            _id: item.item_category,
        });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    try {
        await Item.remove({ _id: itemId });
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    let category_count = category_quantity.max_qty_available - 1;
    try {
        await ItemCategory.updateOne(
            { name: category_quantity.name },
            { $set: { max_qty_available: category_count } }
        );
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    return res.json({
        success: true,
        result: { result: "Item Deleted Successfully" },
    });
};

module.exports.GetItemByVendorId = async (req, res) => {
    const vendorId = req.params.vendorId;
    let result;
    try {
        // result = await Item.find({ vendor_id: vendorId }).populate(
        //     "item_category"
        // );
        result = await Item.find().populate(
            "item_category"
        );
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    return res.json({ success: true, result: { result: result } });
};

module.exports.GetCategoryByVendorId = async (req, res) => {
    const vendorId = req.params.vendorId;
    try {
        // await Item.find({ vendor_id: vendorId }).distinct(
        await Item.find().distinct(
            "item_category",
            function (error, ids) {
                ItemCategory.find({ _id: ids }, function (err, result) {
                    return res.json({
                        success: true,
                        result: { result: result },
                    });
                });
            }
        );
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
};

const ItemTag = require("./../models/MasterDataModels/ItemTag");
const User = require("./../models/MasterDataModels/User");
const Role = require("./../models/MasterDataModels/Role");

module.exports.GetAllTags = async (req, res) => {
    try {
        let result = await ItemTag.find({});
        if (!result) {
            res.json({
                success: false,
                result: { error: "No itemTags Found" },
            });
        } else {
            res.json({ success: true, result: { result: result } });
        }
    } catch (exception) {
        return res.json({ success: false, result: { error: exception } });
    }
};

module.exports.AddItemTag = async (req, res) => {
    const VendorId = req.params.vendorId;
    let existingUser;
    try {
        existingUser = await User.findOne({ _id: VendorId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "Invalid Credentials Could not allow to do this task",
            },
        });
    }

    try {
        RoleOfUser = await Role.findOne({ _id: existingUser.role });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (RoleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    if (!req.body.itemTagDetail.name && !req.body.itemTagDetail.image) {
        return res.json({
            success: false,
            result: { error: "Name and Image are mandatory" },
        });
    }
    const createdItemTag = new ItemTag({
        name: req.body.itemTagDetail.name,
        image: req.body.itemTagDetail.image,
        rank: req.body.itemTagDetail.rank || 1,
    });

    try {
        await createdItemTag.save();
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "ItemTag Added SuccessFully" },
    });
};

module.exports.UpdateItemTag = async (req, res) => {
    const VendorId = req.params.vendorId;
    let existingUser;
    try {
        existingUser = await User.findOne({ _id: VendorId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "Invalid Credentials Could not allow to do this task",
            },
        });
    }
    try {
        RoleOfUser = await Role.findOne({ _id: existingUser.role });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (RoleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    const itemTagId = req.body.itemTagDetail.itemId;
    let result;
    try {
        result = await ItemTag.findOne({ _id: itemTagId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!result) {
        return res.json({
            success: false,
            result: { error: "Item Tag not present in Databse" },
        });
    }
    if (req.body.itemTagDetail.name && req.body.itemTagDetail.image) {
        return res.json({
            success: false,
            result: {
                error: "Name and Image are mandatory for updating a tag",
            },
        });
    }
    const updatedItemTag = {
        name: req.body.itemTagDetail.name,
        image: req.body.itemTagDetail.image,
        rank: req.body.itemTagDetail.rank || 1,
    };
    try {
        await ItemTag.findOneAndUpdate({ _id: itemTagId }, updatedItemTag);
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "Item Tag Updated SuccessFully" },
    });
};

module.exports.DeleteItemTag = async (req, res) => {
    const VendorId = req.params.vendorId;
    const ItemTagId = req.body.itemTagId;
    let existingUser;
    try {
        existingUser = await User.findOne({ _id: VendorId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "Invalid Credentials Could not allow to do this task",
            },
        });
    }

    try {
        RoleOfUser = await Role.findOne({ _id: existingUser.role });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (RoleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        result = await ItemTag.findOne({ _id: ItemTagId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!result) {
        return res.json({
            success: false,
            result: { error: "Item Tag not present in Databse" },
        });
    }

    try {
        await Item.remove({ _id: ItemTagId });
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "ItemTag Deleted SuccessFully" },
    });
};

const MobileBanner = require("./../models/MasterDataModels/mobileBanner");

module.exports.GetMobileBanners = async (req, res) => {
    try {
        let result = await MobileBanner.find({});
        if (!result) {
            res.json({
                success: false,
                result: { error: "No Website Content Found" },
            });
        } else {
            res.json({ success: true, result: { result: result } });
        }
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error || "Something went Wrong" },
        });
    }
};

module.exports.AddMobileBanner = async (req, res) => {
    const { promotional_banner } = req.body;

    const createMobileBanner = new MobileBanner({
        promotional_banner,
    });

    let roleOfUser;
    try {
        await createMobileBanner.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are missing , check body" },
        });
    }
    res.json({
        success: true,
        result: { result: "Banner Added Successfully" },
    });
};

module.exports.DeleteBanner = async (req, res) => {
    try {
        const removevendor = await MobileBanner.remove({ _id: req.params.bannerId });
        res.json({
            success: true,
            result: { result: "Banner Deleted Successfully" },
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: err },
        });
    }
};

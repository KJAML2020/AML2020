const PackagingType = require("./../models/MasterDataModels/PackagingType");
const Role = require("./../models/MasterDataModels/Role");

module.exports.GetAllPackingTypes = async (req, res) => {
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        result = await PackagingType.find({});
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are Mismatched" },
        });
    }

    res.json({
        success: true,
        result: { result: result },
    });
};

module.exports.AddPacking = async (req, res) => {
    console.log("hello");
    const roleId = req.userData.role;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    if (!req.body.packagingDetail.name) {
        return res.json({
            success: false,
            result: { error: "Packaging Name is not Specified" },
        });
    }
    const createdPackagingType = new PackagingType({
        name: req.body.packagingDetail.name,
    });

    try {
        await createdPackagingType.save();
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    return res.json({
        success: true,
        result: { result: "Packaging Detail Added SuccessFully" },
    });
};

module.exports.UpdatePacking = async (req, res) => {
    const roleId = req.userData.role;
    const packageId = req.params.packageId;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let result;
    try {
        result = await PackagingType.findOne({ _id: packageId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    console.log(result)
    if (!result) {
        return res.json({
            success: false,
            result: { error: "package is not present in Database" },
        });
    }

    try {
        await PackagingType.findOneAndUpdate(
            { _id: packageId },
            req.body.packagingDetail
        );
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "Packaging Updated SuccessFully" },
    });
};

module.exports.DeletePackaging = async (req, res) => {
    const roleId = req.userData.role;
    const packageId = req.params.packageId;
    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "VENDOR") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    let package;
    try {
        package = await PackagingType.findOne({ _id: packageId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!package) {
        return res.json({
            success: false,
            result: { error: "Item is not Present" },
        });
    }

    try {
        await PackagingType.remove({ _id: packageId });
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }

    return res.json({
        success: true,
        result: { result: "Pakcage Deleted Successfully" },
    });
};

const mongoose = require("mongoose");
const Role = require("./../models/MasterDataModels/Role");

module.exports.GetRole = async (req, res) => {
    // const roleofUser = req.userData.role;
    // if (roleofUser !== "ADMIN") {
    //     return res.json({
    //         success: false,
    //         result: { error: "You are not authorized" },
    //     });
    // }
    try {
        let result = await Role.find({});
        if (!result) {
            res.json({ success: false, result: { error: "No role Found" } });
        } else {
            res.json({ success: true, result: { result: result } });
        }
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error || "Something went Wrong" },
        });
    }
};

module.exports.AddRole = async (req, res) => {
    const roleofUser = req.userData.role;
    const roleName = req.body.name;
    if (roleofUser !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not authorized" },
        });
    }
    if (!roleName) {
        return res.json({
            success: false,
            result: { error: "Role name not defined" },
        });
    }
    const createdRole = new Role({
        name: roleName,
    });
    try {
        await createdRole.save();
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "Role Added SuccessFully" },
    });
};

module.exports.UpdateRole = async (req, res) => {
    const roleofUser = req.userData.role;
    if (roleofUser !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not authorized" },
        });
    }
    let roleId = req.params.roleId;
    if (!roleId) {
        return res.json({
            success: false,
            result: { error: "Id is not present" },
        });
    }
    try {
        const result = await Role.findOne({ _id: roleId });
        if (!result) {
            res.json({
                success: false,
                result: { error: "No Role found with this id" },
            });
        } else {
            await Role.updateOne(
                { _id: roleId },
                { $set: { name: req.body.name } }
            );
            res.json({
                success: true,
                result: { result: "Role updated SuccessFully" },
            });
        }
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error || "Something went Wrong" },
        });
    }
};

module.exports.DeleteRole = async (req, res) => {
    const roleofUser = req.userData.role;
    if (roleofUser !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not authorized" },
        });
    }
    let roleId = req.params.roleId;
    if (!roleId) {
        return res.json({
            success: false,
            result: { error: "Id is not present" },
        });
    }
    try {
        const result = await Role.findOne({ _id: roleId });
        if (!result) {
            res.json({
                success: false,
                result: { error: "No Role found with this Id" },
            });
        } else {
            await Role.remove({ _id: result._id });
        }
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error || "Something went Wrong" },
        });
    }
    res.json({
        success: true,
        result: { result: "Role Deleted SuccessFully" },
    });
};

const DelieveryStatus = require("./../models/MasterDataModels/DeliveryStatus");
const User = require("./../models/MasterDataModels/User");
const Role = require("./../models/MasterDataModels/Role");

module.exports.GetAllDeleiveryStatus = async (req, res) => {
    // const roleId = req.UserData.role;
    // try {
    //     RoleOfUser = await Role.findOne({ _id: roleId });
    // } catch (err) {
    //     return res.json({ success: false, result: { error: err } });
    // }
    // if (RoleOfUser.name !== "ADMIN") {
    //     return res.json({
    //         success: false,
    //         result: { error: "You are not allowed to do this task" },
    //     });
    // }
    let result;
    try {
        result = await DelieveryStatus.find({});
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (!result) {
        res.json({
            success: false,
            result: { error: "No Delievery Found" },
        });
    } else {
        res.json({ success: true, result: { result: result } });
    }
};

module.exports.CreateDelieveryStatus = async (req, res) => {
    const roleId = req.userData.role;
    const statusName = req.body.name.toUpperCase();
    try {
        RoleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (RoleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    if (!statusName) {
        return res.json({
            success: false,
            result: { error: "DelieveryStatus Name is not defined" },
        });
    }
    const createdDelieveryStatus = new DelieveryStatus({
        status: statusName,
    });

    try {
        await createdDelieveryStatus.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are mismatched , check body" },
        });
    }
    es.json({
        success: true,
        result: { result: "Delievery Status Added SuccessFully" },
    });
};

module.exports.UpdateDelieveryStatus = async (req, res) => {
    const roleId = req.userData.role;

    try {
        RoleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (RoleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    if (req.params.delieveryStatusId) {
        return res.json({
            success: false,
            result: { error: "No Specific Id Found" },
        });
    }

    const delieveryStatusMongoId = await DelieveryStatus.findOne({
        _id: req.params.delieveryStatusId,
    });

    if (!delieveryStatusMongoId) {
        return res.json({
            success: false,
            result: { error: "Delievery status doesn't Exists for this Id" },
        });
    }

    try {
        await DelieveryStatus.findOneAndUpdate(
            { _id: delieveryStatusMongoId._id },
            req.body.delieveryStatusDetail
        );
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "Delievery Status Updated SuccessFully" },
    });
};

module.exports.DeleteDelieveryStatus = async (req, res) => {
    const roleId = req.userData.role;
    try {
        RoleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (RoleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }
    if (!req.parmas.delieveryStatusId) {
        return res.json({
            success: false,
            result: { error: "No Specific Id Found" },
        });
    }

    const delieveryStatusMongoId = await DelieveryStatus.GetOne({
        _id: req.parmas.delieveryStatusId,
    });

    if (!delieveryStatusMongoId) {
        return res.json({
            success: false,
            result: { error: "Delievery status doesn't Exists for this Id" },
        });
    }

    try {
        await DelieveryStatus.remove({
            _id: delieveryStatusMongoId,
        });
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error },
        });
    }
    res.json({
        success: true,
        result: { result: "Delievery Status Deleted SuccessFully" },
    });
};

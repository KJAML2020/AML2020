const User = require("./../models/MasterDataModels/User");
const Customer = require("./../models/UserModels/Customer");
const Role = require("./../models/MasterDataModels/Role");
const Vendor = require("./../models/UserModels/vendors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const sgMail = require("@sendgrid/mail");
const validation = require("../validations/common");
const FCM = require('fcm-node');
const SendOtp = require("sendotp");
const MSG91 = require("msg91-v5");
const msg91 = new MSG91(process.env.OTP_API_KEY,"GCCIND",4)

module.exports.Login = async (req, res) => {
    const { email, password, fcm } = req.body;

    const emailaddress = email.toLowerCase();

    let existingUser;

    try {
        existingUser = await (await User.findOne({ email: emailaddress }));
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!existingUser) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials Could not log you in" },
        });
    }

    let isValidPassword = false;
    try {
        isValidPassword = await bcrypt.compare(password, existingUser.password);
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!isValidPassword) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials Could not log you in" },
        });
    }
    let token;
    try {
        token = jwt.sign(
            { userId: existingUser.id, email: existingUser.email },
            "green_chick_chop"
        );
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Authentication Failed, Try after some time" },
        });
    }

    // Update the FCM token for messaging
    try {
        await User.updateOne({ email: emailaddress }, { $set: { web_fcm: fcm } });
    } catch (err) {
        
    }
    
    res.json({
        success: true,
        result: {
            result: {
                userId: existingUser.id,
                user: existingUser,
                email: existingUser.email,
                token: token,
            },
        },
    });
};

module.exports.Notify = async (req, res) => {
    // const { email, password, fcm } = req.body;

    var serverKey = 'AAAAtXROo6Y:APA91bE146IIaN_ags3lSAIlqIyCWIgke_58u5PpsDpJ3AVHKCKVdPmGt4iojVBrYemicAMND8oV00IJFYLQXxT4MVOtK6VKWlzQo0SdwjHg1ZOsvPNoaTGad8Nz4dHwptd7tRxoBvGf'; //put your server key here
    var fcm = new FCM(serverKey);

    var message = { 
        to: 'f5vngk_2S2am2ECage6P0q:APA91bHrQCWhnY84uOLrSvwTZBLiNTxeEUMAnS1JcvcZfz3M8ZtYbpF5SZbNLn30ZR8Fi84NWZkieRosIKlgR-_wEROXQz3DGnmxrv0gnEB9sGzVsWBr_GK_pyG-ggHLRpl2OerCIA-E', 
        collapse_key: 'your_collapse_key',
        
        notification: {
            title: 'Title of your push notification', 
            body: 'Body of your push notification' 
        },
        
        data: {  
            my_key: 'my value',
            my_another_key: 'my another value'
        }
    };

    fcm.send(message, function(err, response){
        if (err) {
            console.log("Something has gone wrong!");
        } else {
            console.log("Successfully sent with response: ", response);
        }
    });
    
    res.json({
        success: true,
    });
};

module.exports.GetUserByEmail = async (req, res) => {
    const { email } = req.body;

    const emailaddress = email.toLowerCase();

    let existingUser;

    try {
        existingUser = await (await User.findOne({ email: emailaddress }));
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!existingUser) {
        return res.json({
            success: false,
            result: { error: "User does not exists" },
        });
    }

    res.json({
        success: true,
        result: {
            result: {
                userId: existingUser.id,
                user: existingUser,
                email: existingUser.email,
            },
        },
    });
};

module.exports.SendOtp = async (req, res) => {
    const { phoneNumber } = req.body;
    const templateId = "60a89fc6d2ce6855fe33efc6" 
    const params = {
        template_id: templateId, // (Mandatory) You will get it from MSG91 panel
        mobile: phoneNumber, // (Mandatory)  Keep number in international format with country code  
        authkey: process.env.OTP_API_KEY, // (Optional) Auth Key - if added then it will use this key for the particular api call else it will use default key i.e added when creating msg91 object
    }
    const args = {
        "Value1": "Param1",
        "Value2": "Param2",
        "Value3": "Param3"
    };
    msg91.sendOTP(params,args).then((data) => {
        console.log(data)
        if (data.type === "success") {
            return res.json({
                success: true,
                result: {
                    message: "OTP sent successfully",
                },
            });
        }
        if (data.type === "error") {
            return res.json({
                success: false,
                result: {
                    error: data.message,
                },
            });
        }
    }).catch(() => {
        return res.json({
            success: false,
            result: {
                error: data.message,
            },
        });
    })
}

module.exports.MobileLogin = async (req, res) => {
    const { phoneNumber, otp } = req.body;
    const sendOtp = new SendOtp(
        process.env.OTP_API_KEY,
        process.env.OTP_MESSAGE
    );

    const params = {
        mobile: phoneNumber, // (Mandatory)  Keep number in international format with country code  
        authkey: process.env.OTP_API_KEY, // (Optional) Auth Key - if added then it will use this key for the particular api call else it will use default key i.e added when creating msg91 object
        otp: otp, //(Optional) OTP you want to send
        // otp_expiry: "VAL" //(Optional) Expiry time to verify an OTP (default time 10 mins). Mandatory to pass if you pass an expiry time in Send OTP API
    }

    const removedPrefixNumber = phoneNumber.replace(/\D/g, '').slice(-10);
    const mobile = Number(removedPrefixNumber);
    let existingUser;

    try {
        existingUser = await (await User.findOne({ mobile: mobile }));
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!existingUser) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials Could not log you in" },
        });
    }

    msg91.verifyOTP(params).then((data) => {
        if (data.type == "error") {
            return res.json({
                success: false,
                result: { error: data.message },
            });
        }
        if (data.type == "success") {
            let token;
            try {
                token = jwt.sign(
                    { userId: existingUser._id, email: existingUser.email },
                    "green_chick_chop"
                );
            } catch (err) {
                return res.json({
                    success: false,
                    result: {
                        error: "Authentication Failed, Try after some time",
                    },
                });
            }
            return res.json({
                success: true,
                result: {
                    result: {
                        userId: existingUser.id,
                        user: existingUser,
                        email: existingUser.email,
                        token: token,
                    },
                },
            });
        }
    }).catch(() => {
        return res.json({
            success: false,
            result: {
                error: "Authentication Failed, Try after some time",
            },
        });
    })

    // sendOtp.verify(mobile, otp, function (error, data) {
    //     if (data.type == "error") {
    //         return res.json({
    //             success: false,
    //             result: { error: data.message },
    //         });
    //     }
    //     if (data.type == "success") {
    //         let token;
    //         try {
    //             token = jwt.sign(
    //                 { userId: existingUser._id, email: existingUser.email },
    //                 "green_chick_chop"
    //             );
    //         } catch (err) {
    //             return res.json({
    //                 success: false,
    //                 result: {
    //                     error: "Authentication Failed, Try after some time",
    //                 },
    //             });
    //         }
    //         return res.json({
    //             success: true,
    //             result: {
    //                 result: {
    //                     userId: existingUser.id,
    //                     user: existingUser,
    //                     email: existingUser.email,
    //                     token: token,
    //                 },
    //             },
    //         });
    //     }
    // });
};

module.exports.Signup = async (req, res) => {
    const sendOtp = new SendOtp(
        process.env.OTP_API_KEY,
        process.env.OTP_MESSAGE
    );
    const { name, email, mobile, password, scope, fcm } = req.body;
    const user_scope = scope.toUpperCase();
    const emailaddress = email.toLowerCase();
    if (!validation.common.emailRegex.test(emailaddress)) {
        return res.json({
            success: false,
            result: {
                error: "SignUp failed,Email doesn't contain valid format",
            },
        });
    }
    if (!validation.common.passwordRegex.test(password)) {
        return res.json({
            success: false,
            result: {
                error: "SignUp failed,Password doesn't contain valid format",
            },
        });
    }
    // if (!validation.common.phoneNoRegex.test(mobile)) {
    //     return res.json({
    //         success: false,
    //         result: {
    //             error: "SignUp failed,Number doesn't contain valid format",
    //         },
    //     });
    // }
   
    let existingUser;
    try {
        existingUser = await User.findOne({ email: emailaddress });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (existingUser) {
        return res.json({
            success: false,
            result: { error: "User already Exists" },
        });
    }
    let checkMobile;
    try {
        checkMobile = await User.findOne({ mobile: mobile });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (checkMobile) {
        return res.json({
            success: false,
            result: { error: "Number already Exists" },
        });
    }
    sendOtp.send("91" + mobile, "WIZTUTE", function (error, data) {
        if (data.type === "error") {
            return res.json({
                success: false,
                result: {
                    error: data.message,
                },
            });
        }
    });
    sendOtp.setOtpExpiry("1");
    let hashedPassword;
    try {
        hashedPassword = await bcrypt.hash(password, 12);
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    let roleId;
    try {
        roleId = await Role.findOne({ name: user_scope });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    const createdUser = new User({
        name,
        email: emailaddress,
        mobile,
        password: hashedPassword,
        role: roleId._id,
        web_fcm: fcm
    });

    try {
        await createdUser.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Something Went Wrong" },
        });
    }
    if (user_scope === "CUSTOMER") {
        const createdCustomer = new Customer({
            user: createdUser.id,
        });

        try {
            await createdCustomer.save();
        } catch (err) {
            return res.json({
                success: false,
                result: { error: "Something Went Wrong" },
            });
        }
    }
    res.json({
        success: true,
        result: {
            result: {
                userId: createdUser.id,
                email: createdUser.email,
                mobile: createdUser.mobile,
            },
        },
    });
};

module.exports.UpdateUser = async (req, res) => {
    const userId = req.userData.userId;
    let payload;
    if (req.body.name && !req.body.mobile) {
        payload = { name: req.body.name };
    } else if (req.body.name && req.body.mobile) {
        payload = { name: req.body.name, mobile: req.body.mobile };
    } else if (req.body.mobile) {
        payload = { mobile: req.body.mobile };
    } else {
        return res.json({
            success: false,
            result: { error: "Mandatory Field is required" },
        });
    }
    try {
        await User.updateOne({ _id: userId }, { $set: payload });
    } catch (error) {
        return res.json({ success: false, result: { error: err } });
    }
    res.json({
        success: true,
        result: { result: "Credential Update Successfully" },
    });
};

module.exports.GetUser = async (req, res) => {
    const userId = req.userData.userId;
    let existingUser;

    try {
        existingUser = await User.findOne({ _id: userId });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }

    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "Invalid Credential",
            },
        });
    }
    res.json({
        success: true,
        result: {
            result: {
                name: existingUser.name,
                email: existingUser.email,
                mobile: existingUser.mobile,
            },
        },
    });
};

module.exports.ForgotPassword = async (req, res) => {
    const emailAddress = req.body.email;
    const randomNumber = Math.floor(100000 + Math.random() * 900000);
    const url = process.env.RESET_URL;
    if (!emailAddress) {
        return res.json({
            success: false,
            result: {
                error: "email is required",
            },
        });
    }
    let existingUser;
    try {
        existingUser = await User.findOne({ email: emailAddress });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }

    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "User not exists",
            },
        });
    }
    try {
        await User.updateOne(
            { _id: existingUser._id },
            { $set: { verified_token: randomNumber } }
        );
    } catch (error) {
        return res.json({ success: false, result: { error: err } });
    }
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    const resetLink = `${url}/changePassword/${randomNumber}`
    const msg = {
        to: emailAddress,
        from: "info@greenchickchopindia.com",
        subject: 'Recover password',
        text: 'Please use the link below.',
        html: '<strong>'+resetLink+'</strong>'
        // templateId: "d-6a352162550e4b748c649babe8ae49d4",
        // dynamic_template_data: {
        //     resetLink: resetLink,
        // },
    };
    try {
        await sgMail.send(msg);
    } catch (error) {
        return res.json({
            success: false,
            result: { error: "Something went wrong" },
        });
    }
    res.json({
        success: true,
        result: {
            result: "Reset Password link has been sent to your email Id",
        },
    });
};

module.exports.ResetPassword = async (req, res) => {
    const password = req.body.password;
    const user_code = req.params.code;
    if (!password) {
        return res.json({
            success: false,
            result: {
                error: "password Required",
            },
        });
    }
    let existingUser;
    try {
        existingUser = await User.findOne({ verified_token: user_code });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials" },
        });
    }
    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "Invalid Code",
            },
        });
    }

    let hashedPassword;
    try {
        hashedPassword = await bcrypt.hash(password, 12);
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    try {
        await User.updateOne(
            { _id: existingUser._id },
            { $set: { password: hashedPassword, verified_token: null } }
        );
    } catch (error) {
        return res.json({ success: false, result: { error: err } });
    }
    res.json({
        success: true,
        result: {
            result: "Password Updated Successfully",
        },
    });
};

module.exports.ChangePassword = async (req, res) => {
    const password = req.body.password;
    const oldPassword = req.body.oldPassword;
    if (!password && !oldPassword) {
        return res.json({
            success: false,
            result: {
                error: "password Required",
            },
        });
    }
    let existingUser;

    try {
        existingUser = await User.findOne({ _id: req.userData.userId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    let isValidPassword;
    try {
        isValidPassword = await bcrypt.compare(
            oldPassword,
            existingUser.password
        );
    } catch (error) {
        return res.json({
            success: false,
            result: { error: "Password Doesn't match" },
        });
    }
    if (!isValidPassword) {
        return res.json({
            success: false,
            result: { error: "Password Doesn't match" },
        });
    }
    let hashedPassword;
    try {
        hashedPassword = await bcrypt.hash(password, 12);
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    try {
        await User.update(
            { _id: req.userData.userId },
            { $set: { password: hashedPassword } }
        );
    } catch (error) {
        return res.json({ success: false, result: { error: err } });
    }
    res.json({
        success: true,
        result: {
            result: "Password Updated Successfully",
        },
    });
};

module.exports.ChangePasswordWithoutOld = async (req, res) => {
    const password = req.body.password;
    const userId = req.body.userId;
    
    let hashedPassword;
    try {
        hashedPassword = await bcrypt.hash(password, 12);
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    try {
        await User.update(
            { _id: userId },
            { $set: { password: hashedPassword } }
        );
    } catch (error) {
        return res.json({ success: false, result: { error: err } });
    }
    res.json({
        success: true,
        result: {
            result: "Password Updated Successfully",
        },
    });
};

module.exports.FetchNearByVendor = async (req, res) => {
    const { lat, lng } = req.body;

    let vendorList;
    try {
        vendorList = await Vendor.find({});
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    var selected_vendor = [];

    for (var i in vendorList) {
        if (
            calcCrow(
                lat,
                lng,
                vendorList[i].location.latitude,
                vendorList[i].location.longitude
            ) < 2
        ) {
            let distance = calcCrow(lat,lng,vendorList[i].location.latitude,vendorList[i].location.longitude)
            let vendorDetails;
            try {
                vendorDetails = await Vendor.find({
                    user_id: vendorList[i].user_id,
                }).populate("user_id", ["name", "mobile", "email"]);
            } catch (err) {
                return res.json({ success: false, result: { error: err } });
            }
            selected_vendor.push({dist:distance, vendor:vendorDetails});
        }
    }

    function calcCrow(lat1, lon1, lat2, lon2) {
        var R = 6371;
        var dLat = toRad(lat2 - lat1);
        var dLon = toRad(lon2 - lon1);
        var lat1 = toRad(lat1);
        var lat2 = toRad(lat2);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.sin(dLon / 2) *
                Math.sin(dLon / 2) *
                Math.cos(lat1) *
                Math.cos(lat2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c;
        return d;
    }
    // Converts numeric degrees to radians
    function toRad(Value) {
        return (Value * Math.PI) / 180;
    }
    //Now sort the vendor and then collect
    selected_vendor.sort(compareDistance);

    //Now collect all the vendor in an array
    let vendorCollect = [];
    selected_vendor.forEach((item)=>{
        vendorCollect.push(item.vendor)
    })
    res.json({
        success: true,
        result: {
            result: vendorCollect,
        },
    });
};

module.exports.UserOtpRetry = async (req, res) => {
    const sendOtp = new SendOtp(
        process.env.OTP_API_KEY,
        process.env.OTP_MESSAGE
    );
    const { mobile } = req.body;

    sendOtp.retry("91"+mobile, false, function (error, data) {
        if (data.type === "error") {
            return res.json({
                success: false,
                result: {
                    error: data.message,
                },
            });
        }
        if (data.type === "success") {
            return res.json({
                success: true,
                result: {
                    error: data.message,
                },
            });
        }
    });
    sendOtp.setOtpExpiry("1");
};

module.exports.UserOtpVerify = async (req, res) => {
    const sendOtp = new SendOtp(
        process.env.OTP_API_KEY,
        process.env.OTP_MESSAGE
    );
    const { otp, mobile, userId, email } = req.body;
    let existingUser;
    try {
        existingUser = await User.findOne({
            _id: { $in: [userId] },
            email: { $in: [email] },
            mobile: { $in: [mobile] },
        });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }

    if (!existingUser) {
        return res.json({
            success: false,
            result: {
                error: "User not exists",
            },
        });
    }
    sendOtp.verify("91" + mobile, otp, function (error, data) {
        if (data.type == "error") {
            return res.json({
                success: false,
                result: { error: data.message },
            });
        }
        if (data.type == "success") {
            let token;
            try {
                token = jwt.sign(
                    { userId: existingUser._id, email: existingUser.email },
                    "green_chick_chop"
                );
            } catch (err) {
                return res.json({
                    success: false,
                    result: {
                        error: "Authentication Failed, Try after some time",
                    },
                });
            }
            return res.json({
                success: true,
                result: {
                    token: token,
                },
            });
        }
    });
};

function compareDistance(a, b) {
    // Use toUpperCase() to ignore character casing
    const bandA = Math.abs(a.dist);
    const bandB = Math.abs(b.dist);
  
    let comparison = 0;
    if (bandA > bandB) {
      comparison = 1;
    } else if (bandA < bandB) {
      comparison = -1;
    }
    return comparison;
}

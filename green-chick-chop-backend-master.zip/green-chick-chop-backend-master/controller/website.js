const Website = require("./../models/MasterDataModels/website");

module.exports.GetWebsiteDetails = async (req, res) => {
    try {
        let result = await Website.find({});
        if (!result) {
            res.json({
                success: false,
                result: { error: "No Website Content Found" },
            });
        } else {
            res.json({ success: true, result: { result: result } });
        }
    } catch (error) {
        return res.json({
            success: false,
            result: { error: error || "Something went Wrong" },
        });
    }
};

module.exports.AddWebsiteDetail = async (req, res) => {
    // const roleId = req.userData.role;

    const { promotional_banner, description } = req.body;

    const createdWebsiteDetail = new Website({
        promotional_banner,
        description,
    });

    let roleOfUser;
    // try {
    //     roleOfUser = await Role.findOne({ _id: roleId });
    // } catch (err) {
    //     return res.json({ success: false, result: { error: err } });
    // }
    // if (roleOfUser.name !== "ADMIN") {
    //     return res.json({
    //         success: false,
    //         result: { error: "You are not allowed to do this task" },
    //     });
    // }

    try {
        await createdWebsiteDetail.save();
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are missing , check body" },
        });
    }
    res.json({
        success: true,
        result: { result: "Banner Added Successfully" },
    });
};

module.exports.DeleteBanner = async (req, res) => {
    try {
        const removevendor = await Website.remove({ _id: req.params.bannerId });
        res.json({
            success: true,
            result: { result: "Banner Deleted Successfully" },
        });
    } catch (err) {
        return res.json({
            success: false,
            result: { error: err },
        });
    }
};

module.exports.UpdateWebsiteDetail = async (req, res) => {
    const webId = req.params.id;
    const roleId = req.userData.role;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    try {
        await Website.findOneAndUpdate({ _id: webId }, req.body.webDetail);
    } catch (err) {
        return res.json({
            success: false,
            result: { error: "Fields are missing , check body" },
        });
    }
    res.json({
        success: true,
        result: { result: "Banner Updated Successfully" },
    });
};

module.exports.DeleteWebsiteDetail = async (req, res) => {
    const roleId = req.userData.role;

    let roleOfUser;
    try {
        roleOfUser = await Role.findOne({ _id: roleId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    if (roleOfUser.name !== "ADMIN") {
        return res.json({
            success: false,
            result: { error: "You are not allowed to do this task" },
        });
    }

    try {
        await Testimonial.remove({
            _id: req.params.id,
        });
    } catch (error) {
        res.json({
            success: false,
            result: { result: "something went wrong" },
        });
    }
    res.json({
        success: true,
        result: { result: "Website Detail deleted Successfully" },
    });
};

const jwt = require("jsonwebtoken");
const User = require("./../models/MasterDataModels/User");

module.exports = async (req, res, next) => {
    console.log(req.param)
    if (req.method === "OPTIONS") {
        return next();
    }
    let token;
    try {
        token = req.headers.authorization.split(" ")[1]; // Authorization: 'Bearer TOKEN'
    } catch (err) {
        return res.json({
            success: false,
            result: {
                error: "Not Authorized",
            },
        });
    }
    if (!token) {
        return res.json({
            success: false,
            result: {
                error: "Authentication Failed",
            },
        });
    }
    const decodedToken = jwt.verify(token, "green_chick_chop");
    console.log("TOken:", decodedToken.userId)
    let existingUser;
    try {
        existingUser = await User.findOne({ _id: decodedToken.userId });
    } catch (err) {
        return res.json({ success: false, result: { error: err } });
    }
    // console.log(existingUser)
    if (!existingUser) {
        return res.json({
            success: false,
            result: { error: "Invalid Credentials Could not you allow to update" },
        });
    }
    req.userData = { userId: existingUser._id, role: existingUser.role };
    next();
};

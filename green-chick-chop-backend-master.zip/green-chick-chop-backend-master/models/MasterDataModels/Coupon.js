const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CouponSchema = new Schema({
   
    // vendor_id : 
    // {
    //     type : Schema.Types.ObjectId,
    //     ref : 'Vendor'
    // },
    coupon_code : String,
    percent : Number,

});

module.exports = mongoose.model("coupon", CouponSchema);
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const CustomerAddressSchema = new Schema({
   
    customer : {
        type : Schema.Types.ObjectId,
        ref : 'Customer'
    },

    address : { 
        type : String,
        required : true, 
        trim:true
    },
    city : { 
        type : String,
        required : true,
        trim:true
    },

    state : { 
        type : String,
        required : true,
        trim:true
    },
    
    pin_code : { 
        type : Number,
        required : true,
    },

    landmark : String,



})

module.exports = mongoose.model('CustomerAddress', CustomerAddressSchema);
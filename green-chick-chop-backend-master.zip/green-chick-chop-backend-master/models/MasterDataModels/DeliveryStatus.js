const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const DeliveryStatusSchema = new Schema({
    status: {
        type: String,
        enum: [
            "PENDING",
            "PURCHASED",
            "OUT FOR DELIEVERY",
            "DELIVERED",
            "CANCELLED",
        ],
        default: "PENDING",
    },
});

module.exports = mongoose.model("deliveryStatus", DeliveryStatusSchema);

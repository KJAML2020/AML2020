
'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const deliveryTimeSlotSchema = new Schema({
    vendor_id : {
        type: Schema.Types.ObjectId,
        ref : 'Vendor'

    },
    delivery_time_slot:[{
         start_time :{type : String , required : true},
         end_time :{type : String,required:true}
        }],
    delivery_date : String,
    created_on: { type: Date, default: Date.now, required: true }
}, { strict: false });


module.exports = mongoose.model("deliveryTimeSlot", deliveryTimeSlotSchema);

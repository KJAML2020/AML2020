const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ItemCategorySchema = new Schema({
    vendor_id : {
        type: Schema.Types.ObjectId,
        ref : 'Vendor'

    },
    name: String,
    icon: String,
    image: String,
    max_qty_available: { type: Number, default: 0 },
});

module.exports = mongoose.model("ItemCategory", ItemCategorySchema);

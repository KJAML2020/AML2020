const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ItemTagSchema = new Schema({
   
    name : String,
    image : String,
    rank : Number,
})

module.exports = mongoose.model('ItemTag', ItemTagSchema);
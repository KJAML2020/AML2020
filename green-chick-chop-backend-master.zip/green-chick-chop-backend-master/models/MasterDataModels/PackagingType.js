const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PackagingTypeSchema = new Schema({
    name : String
})

module.exports = mongoose.model('PackagingType', PackagingTypeSchema);
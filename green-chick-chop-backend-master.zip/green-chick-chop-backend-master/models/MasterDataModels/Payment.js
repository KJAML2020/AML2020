const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PaymentSchema = new Schema({

    instrument : String,

    amount : {type:Number,required:true},

    discount : {type:Number,default:0},

    payment_ref_id : {

        type : String,
    },

    payment_date :  {

        type : Date,
        default : Date.now,
    },

    status : String,

})
module.exports = mongoose.model('payment', PaymentSchema);
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    name: String,
    mobile: {
        type: Number,
        unique: true,
        required: true,
    },
    email: {
        type: String,
        unique: true,
    },
    password: String,
    created_on: {
        type: Date,
        default: Date.now,
    },

    verified_token: {
        type: Number,
        default: null,
    },

    role: {
        type: Schema.Types.ObjectId,
        ref: "Role",
    },
    web_fcm: String,
});

module.exports = mongoose.model("user", UserSchema);

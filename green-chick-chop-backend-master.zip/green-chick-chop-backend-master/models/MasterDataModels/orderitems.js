
'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const orderItemSchema = new Schema({
    item_id: { type: Schema.Types.ObjectId, ref: "item"},
    quantity:{type:Number},
    created_on: { type: Date, default: Date.now, required: true },
}, { strict: false });


module.exports = mongoose.model("orderItem", orderItemSchema);

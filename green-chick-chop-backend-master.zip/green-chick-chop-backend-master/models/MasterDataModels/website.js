
'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const websiteSchema = new Schema({
    promotional_banner:{ type: String,required: true },
    description:{type:String,require:true},
    created_on: { type: Date, default: Date.now, required: true },
}, { strict: false });


module.exports = mongoose.model("website", websiteSchema);

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CustomerSchema = new Schema({
    user: {
        type: Schema.Types.ObjectId,
        ref: "user",
    },
    image_url: { type: String, default: null },

    current_location: { type: String, default: null },

    last_login: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("Customer", CustomerSchema);

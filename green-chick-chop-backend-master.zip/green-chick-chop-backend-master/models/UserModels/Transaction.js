const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const TransactionSchema = new Schema({
    customer_id : 
    {
        type: Schema.Types.ObjectId,
        ref: "Customer",

    },
    vendor_id: 
    {
        type: Schema.Types.ObjectId,
        ref : "Vendor",
    },
    amount:
    {
        type: Number,
    
    },
    created_date: 
    {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("transaction", TransactionSchema);


'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const querySchema = new Schema({
    user_id: { type: ObjectId, ref: "user",},
    email:{type:String,},
    mobile:{type:String},
    message:{type:String,required:true},
    queryType:{type:String,enum:['payment','login','purchase'],required:true},
    created_on: { type: Date, default: Date.now, required: true }
}, { strict: false });


module.exports = mongoose.model("query", querySchema);

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const testimonialSchema = new Schema({
    // user_id: { type: Schema.Types.ObjectId, ref: "user"},
    name: { type: String, required: true },
    icon: { type: String },
    description: { type: String, required: true },
    image_url: { type: String },
    rating: { type: Number, required: true },
    created_on: { type: Date, default: Date.now, required: true },
});

module.exports = mongoose.model("testimonial", testimonialSchema);

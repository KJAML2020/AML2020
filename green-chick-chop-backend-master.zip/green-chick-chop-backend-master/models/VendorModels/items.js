
'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const ItemSchema = new Schema({
    vendor_id: { type: ObjectId, ref: "vendor", required: true },
    item_category:{type:ObjectId, ref:  "ItemCategory", required:true},
    item_tag:{type:String,default:null},
    max_qty_available:{type:Number},
    name :{type:String,required:true},
    image_url : [{type:String, required:true}],
    packaging_type:{type:String},
    price:{type:Number},
    multi_package : [{type:String}],
    multi_price : [{type:Number}],
    description:{type:String,required:true},
    discount:{type:Number,default:null},
    created_on: { type: Date, default: Date.now, required: true },
    updated_on: { type: Date, default: Date.now, required: true },
}, { strict: false });


module.exports = mongoose.model("Item", ItemSchema);

'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;


var orderPayloadSchema = new Schema({
    itemName : String,
    itemId : String,
    quantity : Number
});

const orderSchema = new Schema({
    customer_id: { type: ObjectId, ref: "customer"},
    vendor_id: { type: ObjectId, ref: "vendor"},
    order_uid:{ type: Number, unique: true },
    order_date:{ type: String,required: true },
    order_time:{ startTime:{type: String,required: true},endTime:{type: String,required: true} },
    delivery_status:{type:ObjectId ,ref:"deliveryStatus",required:true},
    payment:{type:ObjectId,ref:"payment",required:true},
    orderItem:[orderPayloadSchema],
    delievery_address:{type:ObjectId,required:true, ref:"customeraddress"},
    delivery_date: { type: Date, default: null },
    created_on: { type: Date, default: Date.now, required: true },
    updated_on: { type: Date, default: Date.now, required: true },
}, { strict: false });


module.exports = mongoose.model("order", orderSchema);

const express = require("express");
const router = express.Router();
const controller = require("../controller/Customer");
const checkAuth = require("../middleware/check-auth");


router.get("/",controller.GetAllCustomers);
router.get("/details/:userId", controller.GetCustomerById);
router.get("/address/:AddressId", controller.GetCustomerAddressById);
router.post("/add", controller.AddCustomer);
router.patch("/update/:userId", controller.UpdateCustomer);
router.delete("/:userId", controller.DeleteCustomer);
router.use(checkAuth);
router.post("/add-address",controller.AddAddress);
router.get("/get-address",controller.GetAddress);





module.exports = router;
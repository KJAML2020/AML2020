const express = require("express");
const router = express.Router();
const controller = require("../controller/CustomerOrders");
const checkAuth = require("../middleware/check-auth");


router.use(checkAuth);
router.get("/",controller.AllCustomerOrders);
router.get("/analysis/",controller.GetVendorAnalysis);
router.get("/order-detail",controller.GetOrdersDetail);
router.post("/add/:vendorId", controller.AddCustomerOrder);
router.patch("/update/:orderId", controller.UpdateCustomerOrder);
router.patch("/:orderUid", controller.UpdateOrderByVendor);
router.delete("/:orderUid", controller.DeleteCustomerOrder);
router.post("/update_status", controller.UpdateDeliveryStatus);

module.exports = router;
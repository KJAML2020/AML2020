const express = require("express");
const router = express.Router();
const controller = require("../controller/CustomerQueries");

router.get("/",controller.AllCustomerQueries);
router.post("/add", controller.AddCustomerQueries);
router.patch("/update/:userId", controller.UpdateCustomerQueries);
router.delete("/:userId", controller.DeleteCustomerQueries);



module.exports = router;
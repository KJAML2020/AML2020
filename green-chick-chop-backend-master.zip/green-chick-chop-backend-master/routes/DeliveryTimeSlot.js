const express = require("express");
const router = express.Router();
const controller = require("../controller/DeliveryTimeSlot");
const checkAuth = require("../middleware/check-auth");

router.get("/",controller.AllTimeSlots);
router.use(checkAuth);
router.post("/add", controller.AddTimeSlot);
router.patch("/update/:userId", controller.UpdateTimeSlot);
router.delete("/:userId", controller.DeleteTimeSlot);



module.exports = router;
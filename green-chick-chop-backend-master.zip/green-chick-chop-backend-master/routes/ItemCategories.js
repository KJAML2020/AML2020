const express = require("express");
const router = express.Router();
const controller = require("../controller/ItemCategories");
const checkAuth = require("../middleware/check-auth");

router.use(checkAuth);
router.get("/",controller.AllItemCategory);
router.post("/add", controller.AddItemCategory);
router.patch("/update/:userId", controller.UpdateItemCategory);
router.delete("/:userId", controller.DeleteItemCategory);



module.exports = router;
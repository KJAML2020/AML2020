const express = require("express");
const router = express.Router();
const controller = require("../controller/Testimonial");
const checkAuth = require("../middleware/check-auth");

router.get("/",controller.AllTestimonials);
router.use(checkAuth);
router.post("/add", controller.AddTestimonial);
router.patch("/update/:testimonialId", controller.UpdateTestimonial);
router.delete("/:testimonialId", controller.DeleteTestimonial);



module.exports = router;
const express = require("express");
const router = express.Router();
const controller = require("../controller/Transaction");

router.get("/", controller.AllTransaction);
router.post("/add/", controller.AddTransaction);

module.exports = router;
const express = require("express");
const router = express.Router();
const controller = require("../controller/Vendor");

router.get("/",controller.AllVendors);
router.get("/:vendorId",controller.GetVendorById);
router.get("/vendor/:vendorId",controller.GetVendorByVendorId);
router.post("/add", controller.AddVendor);
router.patch("/update/:userId", controller.UpdateVendor);
router.delete("/:userId", controller.DeleteVendor);




module.exports = router;
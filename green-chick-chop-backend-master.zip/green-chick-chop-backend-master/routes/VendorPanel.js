const express = require("express");
const router = express.Router();
const controller = require("../controller/VendorPanel");

router.get("/customer/:userId", controller.GetCustomerById);
router.get("/address/:AddressId", controller.GetCustomerAddressById);
router.get("/analysis", controller.GetAnalysis);


module.exports = router;
const express = require("express");
const router = express.Router();
const controller = require("../controller/item");
const checkAuth = require("../middleware/check-auth");

router.get("/item-detail/:vendorId",controller.GetItemByVendorId);
router.get("/item-category/:vendorId",controller.GetCategoryByVendorId);
router.use(checkAuth);
router.get("/",controller.GetAllItems);
router.get("/:itemId",controller.GetItemById);
router.post("/add/", controller.AddItem);
router.post("/update/:itemId", controller.UpdateItem);
router.delete("/:itemId", controller.DeleteItem);




module.exports = router;
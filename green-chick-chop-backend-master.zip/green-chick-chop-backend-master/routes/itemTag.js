const express = require("express");
const router = express.Router();
const controller = require("../controller/itemTag");

router.get("/", controller.GetAllTags);
router.post("/add/:vendorId", controller.AddItemTag);
router.patch("/update/:vendorId", controller.UpdateItemTag);
router.delete("/:vendorId/:itemTagId", controller.DeleteItemTag);



module.exports = router;
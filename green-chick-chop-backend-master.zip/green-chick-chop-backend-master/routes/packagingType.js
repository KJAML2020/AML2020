const express = require("express");
const router = express.Router();
const controller = require("../controller/packagingType");
const checkAuth = require("../middleware/check-auth");

router.use(checkAuth);
router.route("/").get(controller.GetAllPackingTypes);
router.post("/add/", controller.AddPacking);
router.patch("/update/:packageId", controller.UpdatePacking);
router.delete("/:packageId", controller.DeletePackaging);



module.exports = router;
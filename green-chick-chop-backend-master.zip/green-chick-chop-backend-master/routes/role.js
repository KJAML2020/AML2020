const express = require("express");
const router = express.Router();
const controller = require("../controller/role");
const checkAuth = require("../middleware/check-auth");

// router.use(checkAuth);
router.get("/", controller.GetRole);
router.post("/", controller.AddRole);
router.patch("/update/:roleId", controller.UpdateRole);
router.delete("/:roleId", controller.DeleteRole);



module.exports = router;
const express = require("express");
const router = express.Router();
const controller = require("../controller/statusOfDelievery");
const checkAuth = require("../middleware/check-auth");

router.use(checkAuth);
router.get("/", controller.GetAllDeleiveryStatus);
router.post("/add", controller.CreateDelieveryStatus);
router.patch("/update/:delieveryStatusId", controller.UpdateDelieveryStatus);
router.delete("/:delieveryStatusId", controller.DeleteDelieveryStatus);



module.exports = router;
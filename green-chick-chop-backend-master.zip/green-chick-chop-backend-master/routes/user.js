const express = require("express");
const router = express.Router();
const controller = require("../controller/user");
const checkAuth = require("../middleware/check-auth");


router.post("/", controller.Signup);
router.post("/login", controller.Login);
router.post("/send-otp",controller.SendOtp);
router.post("/mobile-login", controller.MobileLogin);
router.post("/forgot-password",controller.ForgotPassword);
router.post("/verify-otp",controller.UserOtpVerify);
router.post("/selected-vendor",controller.FetchNearByVendor)
router.post("/retry-otp",controller.UserOtpRetry);
router.patch("/reset-password/:code",controller.ResetPassword);
router.use(checkAuth);
router.patch("/",controller.UpdateUser);
router.get("/", controller.GetUser);
router.get("/email/", controller.GetUserByEmail);
router.patch("/change-password",controller.ChangePassword)
router.post("/change-password-bypass",controller.ChangePasswordWithoutOld)
router.get("/notify", controller.Notify);


module.exports = router;

const express = require("express");
const router = express.Router();
const controller = require("../controller/website");
const mobileController = require("../controller/mobileBanner");
const checkAuth = require("../middleware/check-auth");

router.get("/", controller.GetWebsiteDetails);
router.get("/mobile/", mobileController.GetMobileBanners);
router.use(checkAuth);
router.post("/add/", controller.AddWebsiteDetail);
router.post("/mobile/add/", mobileController.AddMobileBanner);
router.patch("/:id", controller.UpdateWebsiteDetail);
router.delete("/:id", controller.DeleteWebsiteDetail);
router.delete("/banner/:bannerId", controller.DeleteBanner);
router.delete("/banner/mobile/:bannerId", mobileController.DeleteBanner);



module.exports = router;